//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CbvD74M_.js
var tsrStartManifest = () => ({
	routes: {
		__root__: {
			filePath: "/dev-server/src/routes/__root.tsx",
			children: [
				"/",
				"/contact",
				"/services"
			],
			assets: void 0,
			preloads: ["/assets/index-DxKfTSVR.js"]
		},
		"/": {
			filePath: "/dev-server/src/routes/index.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/routes-BEJFkGMT.js",
				"/assets/CTABanner-CZvMUdcr.js",
				"/assets/gavel-CPOdH4na.js"
			]
		},
		"/contact": {
			filePath: "/dev-server/src/routes/contact.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/contact-CZDsJFHa.js",
				"/assets/gavel-CPOdH4na.js",
				"/assets/handshake-DIYu_jJJ.js"
			]
		},
		"/services": {
			filePath: "/dev-server/src/routes/services.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/services-BqN9ax_d.js",
				"/assets/CTABanner-CZvMUdcr.js",
				"/assets/gavel-CPOdH4na.js",
				"/assets/handshake-DIYu_jJJ.js"
			]
		}
	},
	clientEntry: "/assets/index-DxKfTSVR.js"
});
//#endregion
export { tsrStartManifest };
