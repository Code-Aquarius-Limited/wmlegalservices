import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, t as Slot } from "../_libs/radix-ui__react-slot+react.mjs";
import { A as Building2, D as CircleCheck, E as Compass, F as ArrowLeft, P as ArrowRight, S as Gavel, a as SquareUserRound, c as RefreshCw, f as MessageSquare, i as Star, j as Briefcase, l as Play, n as Users, o as Shield, r as TrendingDown, y as House } from "../_libs/lucide-react.mjs";
import { n as auction_default, t as CTABanner } from "./CTABanner-B8RHbzvg.mjs";
import { t as useEmblaCarousel } from "../_libs/embla-carousel-react+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CcADXh4K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_default = "/assets/hero-c37LTWVq.jpg";
var property_default = "/assets/property-DJkJLUKS.jpg";
function StatsBar({ stats, variant = "light" }) {
	const dark = variant === "dark";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `grid grid-cols-2 lg:grid-cols-4 ${dark ? "" : "border-y border-border bg-secondary"}`,
		children: stats.map((s, i) => {
			const Icon = s.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					animationDelay: `${i * 150}ms`,
					animationFillMode: "both"
				},
				className: `flex flex-col items-start gap-3 px-6 py-8 lg:px-10 lg:py-10 animate-in fade-in slide-in-from-bottom-2 duration-700 ${i < stats.length - 1 ? "lg:border-r" : ""} ${i < 2 ? "border-b lg:border-b-0" : ""} ${i % 2 === 0 ? "border-r lg:border-r" : ""} ${dark ? "border-primary-foreground/10" : "border-border"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						size: 22,
						className: "text-bronze",
						strokeWidth: 1.5
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `font-serif text-3xl lg:text-4xl ${dark ? "text-primary-foreground" : "text-primary"}`,
						children: s.number
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `text-sm ${dark ? "text-primary-foreground/70" : "text-muted-foreground"}`,
						children: s.label
					})
				]
			}, i);
		})
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var CarouselContext = import_react.createContext(null);
function useCarousel() {
	const context = import_react.useContext(CarouselContext);
	if (!context) throw new Error("useCarousel must be used within a <Carousel />");
	return context;
}
var Carousel = import_react.forwardRef(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
	const [carouselRef, api] = useEmblaCarousel({
		...opts,
		axis: orientation === "horizontal" ? "x" : "y"
	}, plugins);
	const [canScrollPrev, setCanScrollPrev] = import_react.useState(false);
	const [canScrollNext, setCanScrollNext] = import_react.useState(false);
	const onSelect = import_react.useCallback((api) => {
		if (!api) return;
		setCanScrollPrev(api.canScrollPrev());
		setCanScrollNext(api.canScrollNext());
	}, []);
	const scrollPrev = import_react.useCallback(() => {
		api?.scrollPrev();
	}, [api]);
	const scrollNext = import_react.useCallback(() => {
		api?.scrollNext();
	}, [api]);
	const handleKeyDown = import_react.useCallback((event) => {
		if (event.key === "ArrowLeft") {
			event.preventDefault();
			scrollPrev();
		} else if (event.key === "ArrowRight") {
			event.preventDefault();
			scrollNext();
		}
	}, [scrollPrev, scrollNext]);
	import_react.useEffect(() => {
		if (!api || !setApi) return;
		setApi(api);
	}, [api, setApi]);
	import_react.useEffect(() => {
		if (!api) return;
		onSelect(api);
		api.on("reInit", onSelect);
		api.on("select", onSelect);
		return () => {
			api?.off("select", onSelect);
		};
	}, [api, onSelect]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContext.Provider, {
		value: {
			carouselRef,
			api,
			opts,
			orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
			scrollPrev,
			scrollNext,
			canScrollPrev,
			canScrollNext
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			onKeyDownCapture: handleKeyDown,
			className: cn("relative", className),
			role: "region",
			"aria-roledescription": "carousel",
			...props,
			children
		})
	});
});
Carousel.displayName = "Carousel";
var CarouselContent = import_react.forwardRef(({ className, ...props }, ref) => {
	const { carouselRef, orientation } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: carouselRef,
		className: "overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: cn("flex", orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col", className),
			...props
		})
	});
});
CarouselContent.displayName = "CarouselContent";
var CarouselItem = import_react.forwardRef(({ className, ...props }, ref) => {
	const { orientation } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		role: "group",
		"aria-roledescription": "slide",
		className: cn("min-w-0 shrink-0 grow-0 basis-full", orientation === "horizontal" ? "pl-4" : "pt-4", className),
		...props
	});
});
CarouselItem.displayName = "CarouselItem";
var CarouselPrevious = import_react.forwardRef(({ className, variant = "outline", size = "icon", ...props }, ref) => {
	const { orientation, scrollPrev, canScrollPrev } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		variant,
		size,
		className: cn("absolute  h-8 w-8 rounded-full", orientation === "horizontal" ? "-left-12 top-1/2 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90", className),
		disabled: !canScrollPrev,
		onClick: scrollPrev,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Previous slide"
		})]
	});
});
CarouselPrevious.displayName = "CarouselPrevious";
var CarouselNext = import_react.forwardRef(({ className, variant = "outline", size = "icon", ...props }, ref) => {
	const { orientation, scrollNext, canScrollNext } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		variant,
		size,
		className: cn("absolute h-8 w-8 rounded-full", orientation === "horizontal" ? "-right-12 top-1/2 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90", className),
		disabled: !canScrollNext,
		onClick: scrollNext,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Next slide"
		})]
	});
});
CarouselNext.displayName = "CarouselNext";
var defaultReviews = [
	{
		name: "Sarah J.",
		initial: "S",
		date: "2 weeks ago",
		body: "Outstanding service from start to finish. The team kept us informed at every stage and made what could have been a stressful purchase remarkably smooth."
	},
	{
		name: "Michael R.",
		initial: "M",
		date: "1 month ago",
		body: "We bought at auction and needed a fast legal pack review. WM Legal Services turned it around in 48 hours with a clear, plain-English summary. Brilliant."
	},
	{
		name: "Priya K.",
		initial: "P",
		date: "1 month ago",
		body: "As an estate agency, we've worked with many panels. WM's communication and low fall-through rate are genuinely in a different league."
	},
	{
		name: "James W.",
		initial: "J",
		date: "2 months ago",
		body: "Sold our home with no hassle. Knowledgeable, responsive, and they actually picked up the phone — rare these days."
	}
];
function ReviewCard({ review }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "bg-card border border-border rounded-md p-6 shadow-[var(--shadow-soft)] flex flex-col h-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-10 w-10 rounded-full bg-primary text-primary-foreground grid place-items-center font-serif",
					children: review.initial
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium text-foreground",
					children: review.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: review.date
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex items-center gap-0.5",
				children: Array.from({ length: review.rating ?? 5 }).map((_, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
					size: 14,
					className: "text-bronze",
					fill: "currentColor",
					strokeWidth: 0
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-foreground/80 leading-relaxed flex-1",
				children: review.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 text-xs text-muted-foreground",
				children: "Posted on Google"
			})
		]
	});
}
function Testimonials({ reviews = defaultReviews }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "Client Reviews"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-4xl md:text-5xl",
							children: "What our clients say"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-muted-foreground",
							children: "Genuine feedback from buyers, sellers and introducers who have worked with our team."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 hidden gap-6 md:grid md:grid-cols-2 lg:grid-cols-4",
					children: reviews.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewCard, { review: r }, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Carousel, {
						opts: {
							align: "start",
							loop: true
						},
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, {
							className: "-ml-4",
							children: reviews.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, {
								className: "pl-4 basis-[85%] sm:basis-[75%]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewCard, { review: r })
							}, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex items-center justify-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselPrevious, { className: "relative left-0 top-0 translate-x-0 translate-y-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselNext, { className: "relative right-0 top-0 translate-x-0 translate-y-0" })]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex items-center gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://www.google.com/search?q=WM+Legal+Services+reviews",
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-bronze transition-colors",
						children: "Read more reviews on Google →"
					})
				})
			]
		})
	});
}
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden bg-primary",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_default,
					alt: "London skyline at dusk",
					width: 1920,
					height: 1280,
					className: "absolute inset-0 h-full w-full object-cover opacity-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-br from-primary/95 via-primary/85 to-primary/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "container-prose relative py-28 md:py-40 text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow text-bronze",
								children: "Specialist Property Law"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-6 font-serif text-5xl md:text-7xl leading-[1.05] text-primary-foreground",
								children: [
									"Property Law,",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Done Properly."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-7 text-lg md:text-xl text-primary-foreground/80 max-w-2xl leading-relaxed",
								children: "Specialist conveyancing for homebuyers, sellers, auction clients and the introducers who trust us with their referrals."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									hash: "quote",
									className: "inline-flex items-center justify-center rounded-sm bg-bronze px-7 py-3.5 text-sm font-medium text-accent-foreground hover:opacity-90 transition-opacity",
									children: "Get a Quote"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/services",
									hash: "partner-with-us",
									className: "inline-flex items-center justify-center rounded-sm border border-primary-foreground/30 px-7 py-3.5 text-sm font-medium text-primary-foreground hover:bg-primary-foreground/10 transition-colors",
									children: "Partner With Us"
								})]
							})
						]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsBar, { stats: [
			{
				icon: Shield,
				number: "No Sale,",
				label: "No Fee"
			},
			{
				icon: TrendingDown,
				number: "9.2%",
				label: "Fall-through rate"
			},
			{
				icon: CircleCheck,
				number: "1000s",
				label: "Transactions completed"
			},
			{
				icon: Briefcase,
				number: "Specialist",
				label: "Property law team"
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow",
								children: "Our Expertise"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-4xl md:text-5xl",
								children: "How we can help"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-muted-foreground",
								children: "A full-service property law team covering everyday conveyancing, complex transactions and dedicated panel management for introducers."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4",
						children: [
							{
								icon: House,
								t: "Residential & Commercial Conveyancing",
								d: "End-to-end conveyancing for sales, purchases and remortgages."
							},
							{
								icon: Users,
								t: "Conveyancing Panel Management",
								d: "A dedicated extension of your business, from quote to completion."
							},
							{
								icon: RefreshCw,
								t: "Refinance",
								d: "Fast, accurate remortgage transactions with clear communication."
							},
							{
								icon: Building2,
								t: "New Build",
								d: "Specialist handling of tight builder deadlines and reservation contracts."
							}
						].map(({ icon: I, t, d }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-card border border-border rounded-md p-7 hover:shadow-[var(--shadow-card)] transition-shadow",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {
									size: 24,
									className: "text-bronze",
									strokeWidth: 1.5
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-lg font-medium text-primary",
									children: t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground leading-relaxed",
									children: d
								})
							]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 relative overflow-hidden rounded-md bg-primary text-primary-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: auction_default,
								alt: "",
								loading: "lazy",
								width: 1280,
								height: 832,
								className: "absolute inset-0 h-full w-full object-cover opacity-20"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary/60" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative grid md:grid-cols-[1.2fr_1fr] gap-10 p-10 md:p-14 items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "eyebrow text-bronze",
										children: "Our Specialism"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-serif text-3xl md:text-4xl text-primary-foreground",
										children: "Auction Conveyancing Specialists"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 text-primary-foreground/80 leading-relaxed max-w-xl",
										children: "Fast legal pack reviews, fixed-fee options, and a dedicated team built to work to auction deadlines — for buyers, sellers, investors, developers and auction houses."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/services",
										hash: "auctions",
										className: "mt-7 inline-flex items-center gap-2 rounded-sm bg-bronze px-6 py-3 text-sm font-medium text-accent-foreground hover:opacity-90 transition-opacity",
										children: "Explore Auction Services →"
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden md:flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, {
										size: 140,
										strokeWidth: .7,
										className: "text-bronze/80"
									})
								})]
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose grid lg:grid-cols-2 gap-12 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Introduction"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-4xl md:text-5xl",
						children: "Meet William Michael"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground leading-relaxed max-w-lg",
						children: "Hear directly from our founder on what sets WM Legal Services apart — and why specialist property expertise matters more than ever."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-video rounded-md overflow-hidden bg-primary group cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: property_default,
						alt: "Introduction video placeholder",
						loading: "lazy",
						width: 1280,
						height: 832,
						className: "absolute inset-0 h-full w-full object-cover opacity-60 group-hover:opacity-70 transition-opacity"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-20 w-20 rounded-full bg-bronze grid place-items-center shadow-[var(--shadow-card)] group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								size: 28,
								className: "text-accent-foreground ml-1",
								fill: "currentColor"
							})
						})
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Why Choose Us"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-4xl md:text-5xl",
						children: "A different kind of property team"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4",
					children: [
						{
							i: MessageSquare,
							t: "Strong communication",
							d: "We pick up the phone, return emails and keep every party informed."
						},
						{
							i: Compass,
							t: "Commercial approach",
							d: "Pragmatic, deal-driven advice — not box-ticking."
						},
						{
							i: TrendingDown,
							t: "Low fall-through",
							d: "A 9.2% fall-through rate. The industry average is well over double."
						},
						{
							i: Briefcase,
							t: "Specialists, not generalists",
							d: "A dedicated property law team — this is all we do."
						}
					].map(({ i: I, t, d }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {
							size: 22,
							className: "text-bronze",
							strokeWidth: 1.5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 text-lg font-medium text-primary",
							children: t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground leading-relaxed",
							children: d
						})
					] }, t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose grid lg:grid-cols-2 gap-14 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "For Introducers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-4xl md:text-5xl",
						children: "Panel management, properly run"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground leading-relaxed",
						children: "We act as a dedicated extension of your business — quoting leads, allocating instructions, monitoring capacity, and handling escalations — so your clients receive the level of service your brand demands."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						hash: "panel-management",
						className: "mt-8 inline-flex items-center gap-2 rounded-sm bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors",
						children: "Learn About Panel Management →"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-secondary border border-border rounded-md p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-8",
						children: [
							{
								n: "1 lead",
								l: "Single point of contact"
							},
							{
								n: "Same day",
								l: "Quote turnaround"
							},
							{
								n: "Live",
								l: "Pipeline reporting"
							},
							{
								n: "Direct",
								l: "Escalation route"
							}
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-2xl text-primary",
							children: s.n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-wider text-muted-foreground mt-1",
							children: s.l
						})] }, s.n))
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "partner-with-us",
			className: "bg-secondary py-20 md:py-28 scroll-mt-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow",
								children: "For Introducers & Partners"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-4xl md:text-5xl",
								children: "Partner with us"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-muted-foreground",
								children: "Built for estate agents, mortgage brokers and introducers who want their clients treated as carefully as their own brand demands."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4",
						children: [
							{
								t: "No sale, no fee",
								d: "Aligned incentives — we only get paid when your client completes."
							},
							{
								t: "Low fall-through",
								d: "A 9.2% fall-through rate vs. an industry average well over double."
							},
							{
								t: "Communication standards",
								d: "Defined SLAs on response times and pipeline updates."
							},
							{
								t: "Real partnership",
								d: "A dedicated relationship contact, not a faceless inbox."
							}
						].map(({ t, d }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-card border border-border rounded-md p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-medium text-primary",
								children: t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground leading-relaxed",
								children: d
							})]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 rounded-md border-l-2 border-bronze bg-card p-8 md:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "eyebrow",
								children: "Introducer testimonial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
								className: "mt-4 font-serif text-2xl text-primary leading-snug max-w-3xl",
								children: "\"WM have genuinely raised the bar for our clients. Their fall-through rate is exceptional and the communication is the best we've worked with.\""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 text-sm text-muted-foreground",
								children: "Director, Independent Estate Agency · London"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							hash: "partner",
							className: "inline-flex items-center gap-2 rounded-sm bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors",
							children: "Become a Partner →"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "team",
			className: "py-20 md:py-28 scroll-mt-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "Our People"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-4xl md:text-5xl",
							children: "Meet the team"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-muted-foreground",
							children: "Property specialists, not generalists — built around the principle that focused expertise produces better outcomes for clients."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
					children: [
						{
							n: "William Michael",
							r: "Partner at Taylor Rose · CEO, WM Legal Services",
							e: "Auction conveyancing · Investor transactions · Strategy"
						},
						{
							n: "Senior Conveyancer",
							r: "Residential Property",
							e: "Sales, purchases, new build, lease extensions"
						},
						{
							n: "Senior Conveyancer",
							r: "Commercial Property",
							e: "Commercial sales & purchases, BSA matters"
						},
						{
							n: "Auction Team Lead",
							r: "Auction Conveyancing",
							e: "Legal pack reviews, auction completions"
						},
						{
							n: "Panel Manager",
							r: "Panel Management",
							e: "Introducer relationships, escalations, reporting"
						},
						{
							n: "Client Care",
							r: "Client Services",
							e: "Quotes, onboarding, communication"
						}
					].map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "bg-card border border-border rounded-md overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-[4/3] bg-gradient-to-br from-secondary to-border grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareUserRound, {
								size: 56,
								strokeWidth: .8,
								className: "text-primary/30"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-medium text-primary",
									children: p.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-xs uppercase tracking-wider text-bronze",
									children: p.r
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted-foreground leading-relaxed",
									children: p.e
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "mailto:enquiries@wmlegalservices.co.uk",
									className: "mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary hover:text-bronze transition-colors",
									children: "Contact →"
								})
							]
						})]
					}, idx))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTABanner, {})
	] });
}
//#endregion
export { HomePage as component };
