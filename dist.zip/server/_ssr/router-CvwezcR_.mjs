import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as lazyRouteComponent, d as Link, f as useNavigate, i as useLocation, l as createFileRoute, n as Scripts, o as createRouter, p as useRouter, r as HeadContent, s as Outlet, u as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-slot+react.mjs";
import { h as Mail, k as ChevronDown, m as MapPin, p as Menu, t as X, u as Phone, v as Instagram } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CvwezcR_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DaFfYUPu.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var WM_Legal_Services_Logo_png_asset_default = {
	version: 1,
	asset_id: "c0855348-b23c-40af-9ffd-d9246f98d4f4",
	project_id: "e215da2e-cce2-44ae-9c60-4d26e019d365",
	url: "/__l5e/assets-v1/c0855348-b23c-40af-9ffd-d9246f98d4f4/WM_Legal_Services_Logo.png",
	r2_key: "a/v1/e215da2e-cce2-44ae-9c60-4d26e019d365/c0855348-b23c-40af-9ffd-d9246f98d4f4/WM_Legal_Services_Logo.png",
	original_filename: "WM_Legal_Services_Logo.png",
	size: 829574,
	content_type: "image/png",
	created_at: "2026-06-22T12:27:47Z"
};
var serviceLinks = [
	{
		to: "/services",
		hash: "conveyancing",
		label: "Conveyancing & Property Services"
	},
	{
		to: "/services",
		hash: "auctions",
		label: "Auction Conveyancing Specialists"
	},
	{
		to: "/services",
		hash: "panel-management",
		label: "Panel Management"
	}
];
function Header() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	const location = useLocation();
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 8);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const scrollToService = (hash) => {
		const el = document.getElementById(hash);
		if (el) el.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	};
	const handleServiceClick = async (event, hash) => {
		event.preventDefault();
		setOpen(false);
		if (location.pathname === "/services" && location.hash?.replace("#", "") === hash) {
			scrollToService(hash);
			return;
		}
		await navigate({
			to: "/services",
			hash,
			resetScroll: false
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `sticky top-0 z-50 w-full transition-all ${scrolled ? "bg-background/85 backdrop-blur-md border-b border-border" : "bg-background/70 backdrop-blur-sm"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose flex h-28 items-center justify-between gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 group",
					onClick: () => setOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: WM_Legal_Services_Logo_png_asset_default.url,
						alt: "WM Legal Services",
						className: "h-20 w-auto object-contain"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden md:flex items-center gap-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "text-sm font-medium text-foreground/80 hover:text-primary transition-colors",
							activeProps: { className: "text-primary" },
							activeOptions: { exact: true },
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex items-center gap-1 text-sm font-medium text-foreground/80 transition-colors hover:text-primary focus:text-primary focus:outline-none",
								children: ["Our Services", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
									size: 14,
									className: "shrink-0 transition-transform duration-200 group-hover:rotate-180 group-focus-within:rotate-180"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "invisible absolute left-0 top-full z-50 min-w-[16rem] rounded-md border bg-popover p-1 text-popover-foreground opacity-0 shadow-md transition-opacity duration-150 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100",
								children: serviceLinks.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `${s.to}#${s.hash}`,
									onClick: (event) => handleServiceClick(event, s.hash),
									className: "block rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
									children: s.label
								}, s.hash))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "text-sm font-medium text-foreground/80 hover:text-primary transition-colors",
							activeProps: { className: "text-primary" },
							activeOptions: { exact: true },
							children: "Contact Us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							hash: "quote",
							className: "inline-flex items-center justify-center rounded-sm bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors",
							children: "Get a Quote"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Open menu",
					className: "md:hidden inline-flex h-10 w-10 items-center justify-center rounded-sm border border-border text-primary",
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "md:hidden border-t border-border bg-background",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose py-4 flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						onClick: () => setOpen(false),
						className: "py-3 text-sm font-medium text-foreground/80 border-b border-border/60",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-3 border-b border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium text-foreground/80",
							children: "Our Services"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 ml-3 space-y-1 border-l border-border pl-3",
							children: serviceLinks.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `${s.to}#${s.hash}`,
								onClick: (event) => handleServiceClick(event, s.hash),
								className: "block py-1.5 text-sm text-foreground/70 hover:text-primary",
								children: s.label
							}) }, s.hash))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						onClick: () => setOpen(false),
						className: "py-3 text-sm font-medium text-foreground/80 border-b border-border/60",
						children: "Contact Us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						hash: "quote",
						onClick: () => setOpen(false),
						className: "mt-3 inline-flex items-center justify-center rounded-sm bg-primary px-5 py-3 text-sm font-medium text-primary-foreground",
						children: "Get a Quote"
					})
				]
			})
		})]
	});
}
var WM_Legal_Services_Logo_white_png_asset_default = {
	version: 1,
	asset_id: "7d871eb8-cbe8-4780-ba58-a17860258889",
	project_id: "e215da2e-cce2-44ae-9c60-4d26e019d365",
	url: "/__l5e/assets-v1/7d871eb8-cbe8-4780-ba58-a17860258889/WM_Legal_Services_Logo_white.png",
	r2_key: "a/v1/e215da2e-cce2-44ae-9c60-4d26e019d365/7d871eb8-cbe8-4780-ba58-a17860258889/WM_Legal_Services_Logo_white.png",
	original_filename: "WM_Legal_Services_Logo_white.png",
	size: 95558,
	content_type: "image/png",
	created_at: "2026-06-22T12:56:58Z"
};
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-primary text-primary-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose py-16 grid gap-12 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2 max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: WM_Legal_Services_Logo_white_png_asset_default.url,
							alt: "WM Legal Services",
							className: "h-24 w-auto object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-primary-foreground/70 leading-relaxed",
							children: "Specialist property law team operating under Taylor Rose — one of the largest property law firms in the UK."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://instagram.com/1propertylawyer",
							target: "_blank",
							rel: "noreferrer",
							"aria-label": "Instagram @1propertylawyer",
							className: "mt-6 inline-flex items-center text-primary-foreground/80 hover:text-bronze transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								size: 24,
								strokeWidth: 1.5
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-sm font-medium tracking-wide uppercase text-bronze",
					children: "Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-5 space-y-3 text-sm text-primary-foreground/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								size: 14,
								className: "mt-1 shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "020 3292 0669" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
								size: 14,
								className: "mt-1 shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:enquiries@wmlegalservices.co.uk",
								className: "hover:text-bronze",
								children: "enquiries@wmlegalservices.co.uk"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								size: 14,
								className: "mt-1 shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "30 Churchill Place, London, E14 5RE" })]
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-sm font-medium tracking-wide uppercase text-bronze",
					children: "Quick Links"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-5 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Home"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Our Services"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services",
							hash: "auctions",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Auction Conveyancing"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services",
							hash: "panel-management",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Panel Management"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							hash: "partner-with-us",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Partner With Us"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "text-primary-foreground/80 hover:text-bronze",
							children: "Contact"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-primary-foreground/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-primary-foreground/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" WM Legal Services. Operating under Taylor Rose."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Authorised & regulated by the Solicitors Regulation Authority." })]
			})
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-7xl text-primary",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-medium",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex items-center justify-center rounded-sm bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground",
					children: "Go home"
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-medium",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Please try again or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-sm border border-input bg-background px-4 py-2 text-sm font-medium",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$3 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "WM Legal Services — Specialist Property Law In London" },
			{
				name: "description",
				content: "Specialist property law team based in London. Conveyancing, auction conveyancing, panel management and partner services."
			},
			{
				property: "og:title",
				content: "WM Legal Services — Specialist Property Law In London"
			},
			{
				property: "og:description",
				content: "Specialist property law team based in London. Conveyancing, auction conveyancing, panel management and partner services."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "WM Legal Services — Specialist Property Law In London"
			},
			{
				name: "twitter:description",
				content: "Specialist property law team based in London. Conveyancing, auction conveyancing, panel management and partner services."
			},
			{
				property: "og:image",
				content: "https://storage.googleapis.com/gpt-engineer-file-uploads/hVwWIy58G2ZiNS1DGn6qNrbja4y2/social-images/social-1782143284675-WM_Legal_Services_Social_Image.webp"
			},
			{
				name: "twitter:image",
				content: "https://storage.googleapis.com/gpt-engineer-file-uploads/hVwWIy58G2ZiNS1DGn6qNrbja4y2/social-images/social-1782143284675-WM_Legal_Services_Social_Image.webp"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap"
			}
		],
		scripts: []
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$3.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
			]
		})
	});
}
var $$splitComponentImporter$2 = () => import("./services-CRmARKrC.mjs");
var Route$2 = createFileRoute("/services")({
	head: () => ({ meta: [
		{ title: "Our Services — WM Legal Services" },
		{
			name: "description",
			content: "Conveyancing, auction conveyancing, panel management, partner services and our specialist property law team."
		},
		{
			property: "og:title",
			content: "Our Services — WM Legal Services"
		},
		{
			property: "og:description",
			content: "Specialist property law expertise, from everyday conveyancing to complex auction transactions."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./contact-C7MPBbWZ.mjs");
var Route$1 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Contact Us — WM Legal Services" },
		{
			name: "description",
			content: "Get in touch with the WM Legal Services property law team. Quotes, instructions, partnerships and general enquiries."
		},
		{
			property: "og:title",
			content: "Contact Us — WM Legal Services"
		},
		{
			property: "og:description",
			content: "Whether you're looking for a quote, ready to instruct, or interested in partnering — we're here to help."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./routes-CcADXh4K.mjs");
var Route = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "WM Legal Services — Property Law, Done Properly" },
		{
			name: "description",
			content: "Specialist conveyancing for homebuyers, sellers, auction clients and introducers. Operating under Taylor Rose."
		},
		{
			property: "og:title",
			content: "WM Legal Services — Property Law, Done Properly"
		},
		{
			property: "og:description",
			content: "Specialist conveyancing for homebuyers, sellers, auction clients and introducers."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var ServicesRoute = Route$2.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$3
});
var ContactRoute = Route$1.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$3
});
var rootRouteChildren = {
	IndexRoute: Route.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	ContactRoute,
	ServicesRoute
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
