import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-slot+react.mjs";
import { S as Gavel, b as Handshake, h as Mail, m as MapPin, u as Phone } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-C7MPBbWZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUBJECTS = {
	general: "General Enquiry — WM Legal Services",
	quote: "Quote Request — WM Legal Services",
	"auction legal pack": "Auction Legal Pack Review Request",
	"auction callback": "Auction Call-Back Request",
	partner: "Partner Enquiry — WM Legal Services"
};
var TITLES = {
	general: "Send us a message",
	quote: "Request a quote",
	"auction legal pack": "Request a legal pack review",
	"auction callback": "Request a call back",
	partner: "Partner with us"
};
function EnquiryForm({ formType = "general", showTypeSelector = false, compact = false, title }) {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [type, setType] = (0, import_react.useState)(formType);
	const onSubmit = (e) => {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const name = String(fd.get("name") || "").trim();
		const email = String(fd.get("email") || "").trim();
		const phone = String(fd.get("phone") || "").trim();
		const scheduleCall = String(fd.get("scheduleCall") || "").trim();
		const message = String(fd.get("message") || "").trim();
		const subject = encodeURIComponent(SUBJECTS[type]);
		const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nDiscovery call date: ${scheduleCall || "Not requested"}\nEnquiry type: ${type}\n\nMessage:\n${message}`);
		window.location.href = `mailto:enquiries@wmlegalservices.co.uk?subject=${subject}&body=${body}`;
		setSent(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: `bg-card border border-border rounded-md ${compact ? "p-6" : "p-8 md:p-10"} shadow-[var(--shadow-card)]`,
		children: [
			title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-2xl mb-1",
				children: title
			}),
			!title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-2xl mb-1",
				children: TITLES[type]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground mb-6",
				children: "We'll get back to you the same working day."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						name: "name",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						name: "email",
						type: "email",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						name: "phone",
						type: "tel"
					}),
					showTypeSelector && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-medium text-foreground/80 mb-1.5",
							children: "Enquiry type"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: type,
							onChange: (e) => setType(e.target.value),
							className: "h-11 rounded-sm border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "general",
									children: "General Enquiry"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "quote",
									children: "Get a Quote"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "auction legal pack",
									children: "Auction Legal Pack Review"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "partner",
									children: "Partner With Us"
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-medium text-foreground/80 mb-1.5",
					children: "Schedule a date for a discovery call"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					name: "scheduleCall",
					className: "h-11 rounded-sm border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 md:w-1/2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-medium text-foreground/80 mb-1.5",
					children: "Message"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "message",
					rows: 5,
					required: true,
					maxLength: 2e3,
					className: "rounded-sm border border-input bg-background px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "mt-6 inline-flex items-center justify-center rounded-sm bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors",
				children: sent ? "Opening your email…" : "Send enquiry"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted-foreground",
				children: "By submitting, you agree to be contacted regarding your enquiry. We never share your details."
			})
		]
	});
}
function Field({ label, name, type = "text", required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "text-xs font-medium text-foreground/80 mb-1.5",
			children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-bronze",
				children: " *"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			name,
			required,
			maxLength: 200,
			className: "h-11 rounded-sm border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40"
		})]
	});
}
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "eyebrow",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-5xl md:text-6xl max-w-3xl",
					children: "Get in touch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-muted-foreground text-lg",
					children: "Whether you're looking for a quote, ready to instruct us, or interested in partnering with our team — we're here to help."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose grid gap-12 lg:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "quote",
				className: "scroll-mt-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiryForm, {
					formType: "general",
					showTypeSelector: true
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "space-y-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-md p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xl font-medium text-primary",
						children: "Direct contact"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									size: 16,
									className: "mt-0.5 text-bronze shrink-0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs uppercase tracking-wider text-muted-foreground",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "tel:+442032920669",
									className: "font-medium text-foreground hover:text-bronze",
									children: "020 3292 0669"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									size: 16,
									className: "mt-0.5 text-bronze shrink-0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs uppercase tracking-wider text-muted-foreground",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "mailto:enquiries@wmlegalservices.co.uk",
									className: "font-medium text-foreground hover:text-bronze break-all",
									children: "enquiries@wmlegalservices.co.uk"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									size: 16,
									className: "mt-0.5 text-bronze shrink-0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs uppercase tracking-wider text-muted-foreground",
									children: "Office"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-medium text-foreground",
									children: [
										"30 Churchill Place",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"London, E14 5RE"
									]
								})] })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-md p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-medium text-primary",
						children: "Looking for something specific?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/services",
							hash: "auctions",
							className: "group flex items-center gap-3 p-3 rounded-sm border border-border hover:border-bronze transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, {
								size: 18,
								className: "text-bronze",
								strokeWidth: 1.5
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-foreground group-hover:text-primary",
								children: "Auction enquiries"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/services",
							hash: "partner-with-us",
							className: "group flex items-center gap-3 p-3 rounded-sm border border-border hover:border-bronze transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handshake, {
								size: 18,
								className: "text-bronze",
								strokeWidth: 1.5
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-foreground group-hover:text-primary",
								children: "Partner / introducer enquiries"
							})]
						})]
					})]
				})]
			})]
		})
	})] });
}
//#endregion
export { ContactPage as component };
