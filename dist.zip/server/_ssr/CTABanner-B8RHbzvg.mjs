import { d as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-slot+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CTABanner-B8RHbzvg.js
var import_jsx_runtime = require_jsx_runtime();
var auction_default = "/assets/auction-DgDEOzLk.jpg";
function CTABanner({ heading = "Ready to get started?", sub = "Whether you're buying, selling, instructing on an auction, or referring clients — our team is ready to help." }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-primary text-primary-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-prose py-20 md:py-24 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hairline mb-6 bg-bronze" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-4xl md:text-5xl text-primary-foreground",
					children: heading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-xl mx-auto text-primary-foreground/75",
					children: sub
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap gap-3 justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						hash: "quote",
						className: "inline-flex items-center justify-center rounded-sm bg-bronze px-7 py-3.5 text-sm font-medium text-accent-foreground hover:opacity-90 transition-opacity",
						children: "Get a Quote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						hash: "partner-with-us",
						className: "inline-flex items-center justify-center rounded-sm border border-primary-foreground/30 bg-transparent px-7 py-3.5 text-sm font-medium text-primary-foreground hover:bg-primary-foreground/10 transition-colors",
						children: "Partner With Us"
					})]
				})
			]
		})
	});
}
//#endregion
export { auction_default as n, CTABanner as t };
