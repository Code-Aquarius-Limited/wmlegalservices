import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as Link, i as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-slot+react.mjs";
import { A as Building2, C as FileSearch, M as BadgeCheck, N as ArrowUp, O as ChevronRight, S as Gavel, T as Download, _ as KeyRound, b as Handshake, c as RefreshCw, d as PhoneCall, g as ListChecks, n as Users, s as ShieldCheck, w as FilePenLine, x as HandCoins, y as House } from "../_libs/lucide-react.mjs";
import { n as auction_default, t as CTABanner } from "./CTABanner-B8RHbzvg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-CRmARKrC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BackToTop() {
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setVisible(window.scrollY > 800);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: () => window.scrollTo({
			top: 0,
			behavior: "smooth"
		}),
		"aria-label": "Back to top",
		className: "fixed bottom-6 right-6 z-40 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-[var(--shadow-card)] grid place-items-center hover:bg-primary/90 transition-colors",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { size: 18 })
	});
}
var pillars = [
	{
		id: "conveyancing",
		icon: House,
		t: "Conveyancing & Property Services",
		d: "Sales, purchases, remortgages and the full range of residential and commercial work."
	},
	{
		id: "auctions",
		icon: Gavel,
		t: "Auction Conveyancing",
		d: "Our specialism — fast legal pack reviews and full auction transaction handling.",
		spotlight: true
	},
	{
		id: "panel-management",
		icon: Users,
		t: "Panel Management",
		d: "A dedicated extension of estate agency and mortgage brokerage businesses."
	}
];
function ServicesPage() {
	const { hash } = useLocation();
	(0, import_react.useEffect)(() => {
		const targetHash = hash || window.location.hash;
		if (!targetHash) return;
		const id = targetHash.replace("#", "");
		const scrollToSection = () => {
			const el = document.getElementById(id);
			if (el) el.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
		};
		const frame = window.requestAnimationFrame(scrollToSection);
		return () => window.cancelAnimationFrame(frame);
	}, [hash]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose py-20 md:py-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Our Services"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-5xl md:text-6xl max-w-3xl",
						children: "Our services"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-2xl text-muted-foreground text-lg",
						children: "Specialist property law expertise, from everyday conveyancing to complex auction transactions."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-prose",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: pillars.map((p) => {
						const I = p.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `#${p.id}`,
							className: "group block rounded-md border border-border bg-card p-7 transition-all hover:bg-primary hover:border-primary hover:shadow-[var(--shadow-card)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {
									size: 24,
									strokeWidth: 1.5,
									className: "text-bronze"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-lg font-medium text-primary transition-colors group-hover:text-bronze",
									children: p.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground transition-colors group-hover:text-bronze/80",
									children: p.d
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-5 inline-flex items-center gap-1 text-sm font-medium text-primary transition-colors group-hover:text-bronze",
									children: ["Read more ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 14 })]
								})
							]
						}, p.id);
					})
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "conveyancing",
			className: "bg-secondary py-20 md:py-28 scroll-mt-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "Core Conveyancing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-4xl md:text-5xl",
							children: "Conveyancing & property services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-muted-foreground leading-relaxed",
							children: "Plain-English, deal-driven property law across the spectrum of residential and commercial transactions."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: [
						{
							i: House,
							t: "Residential & Commercial Conveyancing",
							d: "Full-service handling of sales and purchases for owner-occupiers, landlords and businesses."
						},
						{
							i: Building2,
							t: "New Build Conveyancing",
							d: "Specialist handling of reservation deadlines, builder contracts and developer requirements."
						},
						{
							i: RefreshCw,
							t: "Refinance",
							d: "Remortgage transactions managed with speed and clarity, working directly with your lender."
						},
						{
							i: FilePenLine,
							t: "Transfer of Equity",
							d: "Adding or removing parties from a property title — including separations and gifted shares."
						},
						{
							i: KeyRound,
							t: "Lease Extensions",
							d: "Statutory and informal lease extensions handled with experienced leasehold expertise."
						},
						{
							i: HandCoins,
							t: "Shared Ownership",
							d: "Purchases, staircasing and resales of shared ownership properties."
						},
						{
							i: ShieldCheck,
							t: "Building Safety Act Matters",
							d: "Specialist advice on the legal implications of the Building Safety Act for buyers and owners."
						}
					].map(({ i: I, t, d }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-md p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {
								size: 22,
								className: "text-bronze",
								strokeWidth: 1.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-base font-medium text-primary",
								children: t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground leading-relaxed",
								children: d
							})
						]
					}, t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "auctions",
			className: "relative bg-primary text-primary-foreground py-20 md:py-28 scroll-mt-20 overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: auction_default,
				alt: "",
				loading: "lazy",
				width: 1280,
				height: 832,
				className: "absolute inset-0 h-full w-full object-cover opacity-10"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative container-prose",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow text-bronze",
								children: "Our Specialism"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 font-serif text-4xl md:text-5xl text-primary-foreground",
								children: "Auction conveyancing specialists"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-primary-foreground/80 leading-relaxed",
								children: "WM Legal Services is a leading auction conveyancing team for buyers, sellers, investors, developers and auction houses. Fast turnaround, fixed-fee options, and a team that genuinely understands the pressure of auction deadlines."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotBlock, {
						icon: FileSearch,
						title: "Auction Legal Pack Reviews",
						body: "Fast turnaround (often within 48 hours), fixed-fee packages, and a plain-English summary that highlights risks, title issues, lease terms, special conditions, and any other points worth knowing before you bid.",
						cta: {
							to: "/contact",
							hash: "legal-pack",
							label: "Request a Legal Pack Review"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl text-primary-foreground",
								children: "Buying at Auction"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-8 grid md:grid-cols-5 gap-4",
								children: [
									"Get the legal pack reviewed",
									"Arrange finance",
									"Register to bid",
									"Exchange on the fall of the hammer",
									"Complete within the auction timescale"
								].map((step, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-md border border-primary-foreground/15 bg-primary-foreground/5 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-serif text-2xl text-bronze",
										children: String(idx + 1).padStart(2, "0")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-primary-foreground/80 leading-relaxed",
										children: step
									})]
								}, step))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 rounded-md border-l-2 border-bronze bg-primary-foreground/5 px-6 py-5 text-sm text-primary-foreground/80 leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-bronze font-medium",
									children: "Important:"
								}), " auction contracts are binding on the fall of the hammer. A proper legal pack review before bidding is the single best protection against expensive surprises."]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotBlock, {
						icon: ListChecks,
						title: "Selling at Auction",
						body: "Legal pack preparation, fast instruction processes and direct coordination with your chosen auction house — so your lot is ready to sell on the catalogue deadline."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl text-primary-foreground",
							children: "Investor & Developer Services"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-5",
							children: [
								"Portfolio acquisitions",
								"Limited company purchases",
								"Bridging finance transactions",
								"Commercial auction purchases",
								"Development opportunities"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-primary-foreground/15 bg-primary-foreground/5 p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
									size: 18,
									className: "text-bronze",
									strokeWidth: 1.5
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-medium text-primary-foreground",
									children: t
								})]
							}, t))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotBlock, {
						icon: Handshake,
						title: "Auction House Partnerships",
						body: "Service standards, fast turnaround times, dedicated points of contact, capacity for volume instructions, and the ability to work consistently to tight auction deadlines.",
						cta: {
							to: "/contact",
							hash: "partner",
							label: "Partner With Us"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-4 md:grid-cols-2",
						children: [{
							t: "Buyer's Guide to Auction Conveyancing",
							d: "Everything to know before bidding."
						}, {
							t: "Seller's Guide to Auction Conveyancing",
							d: "How to prepare a lot that sells smoothly."
						}].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#",
							className: "group flex items-center gap-5 rounded-md border border-primary-foreground/15 bg-primary-foreground/5 p-6 hover:bg-primary-foreground/10 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-12 w-12 shrink-0 rounded-sm bg-bronze/15 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									size: 20,
									className: "text-bronze"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium text-primary-foreground",
									children: g.t
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-primary-foreground/70",
									children: g.d
								})]
							})]
						}, g.t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 rounded-md border border-primary-foreground/15 bg-primary-foreground/5 p-8 md:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, {
								size: 28,
								className: "text-bronze shrink-0 mt-1",
								strokeWidth: 1.5
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl text-primary-foreground",
								children: "Prefer a call back?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-primary-foreground/70 max-w-md",
								children: "Tell us when suits and one of our auction team will be in touch the same working day."
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							hash: "callback",
							className: "inline-flex items-center justify-center rounded-sm bg-bronze px-6 py-3 text-sm font-medium text-accent-foreground hover:opacity-90 transition-opacity",
							children: "Request a Call Back"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "panel-management",
			className: "py-20 md:py-28 scroll-mt-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-prose grid lg:grid-cols-[1fr_1.2fr] gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "eyebrow",
					children: "Panel Management"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-4xl md:text-5xl",
					children: "Panel management for estate agents & mortgage brokers"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5 text-foreground/85 leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We act as a dedicated extension of your business — quoting new leads, allocating instructions to the right firm or fee-earner, monitoring capacity, and maintaining the panel relationships that keep your pipeline flowing." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Our team handles escalations and complaints directly, so issues never drag on your client relationships, and reports back to you with the operational visibility your business needs to plan ahead." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The result: better communication, fewer fall-throughs, less administrative burden on your team — and a level of service that reflects positively on your brand." })
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTABanner, {
			heading: "Let's talk",
			sub: "Whatever the property matter — we'd like to hear from you."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackToTop, {})
	] });
}
function SpotBlock({ icon: I, title, body, cta }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-14 grid md:grid-cols-[auto_1fr] gap-6 md:gap-8 items-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-14 w-14 rounded-sm bg-bronze/15 grid place-items-center shrink-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {
				size: 24,
				className: "text-bronze",
				strokeWidth: 1.5
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-2xl text-primary-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-primary-foreground/80 leading-relaxed max-w-3xl",
				children: body
			}),
			cta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: cta.to,
				hash: cta.hash,
				className: "mt-5 inline-flex items-center gap-2 rounded-sm bg-bronze px-5 py-2.5 text-sm font-medium text-accent-foreground hover:opacity-90 transition-opacity",
				children: [cta.label, " →"]
			})
		] })]
	});
}
//#endregion
export { ServicesPage as component };
